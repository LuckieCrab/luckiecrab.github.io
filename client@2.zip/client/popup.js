let user = {};

chrome.storage.sync.get({
    name: '',
    id: '',
    password: '',
    darkmode: 'undefined'
}, function (items) {
    if(items.name == '' || items.id == '' || items.password == '') {
        if (chrome.runtime.openOptionsPage) {
            chrome.runtime.openOptionsPage();
        } else {
            window.open(chrome.runtime.getURL('options.html'));
        }
    }
    
    user.name = items.name;
    user.id = items.id;
    user.password = items.password;
    user.darkmode = items.darkmode;
});

async function whatTheFunction () {
    let tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];

    if(tab.url.startsWith('https://www.rekensite.nl/rekenen/exercise/')) {
        let id = tab.url.split('https://www.rekensite.nl/rekenen/exercise/')[1].split("/")[0];
        
        if(!id) {
            document.getElementById('message').children[0].textContent = "Hey, je bent niet bij een opdracht dus hier is geen antwoord voor vinden \u00af\u005c\u005f\u0028\u30c4\u0029\u005f\u002f\u00af"

            document.getElementById('tab1').classList.add('noAnswer');
        }

        let res = await (await fetch(`https://luckie.peiphy.xyz/api/getAnswer?id=${id}&username=${user.name}&userId=${user.id}&password=${user.password}`)).json();

        if(res.code == 401) {
            if (chrome.runtime.openOptionsPage) {
                chrome.runtime.openOptionsPage();
            } else {
                window.open(chrome.runtime.getURL('options.html'));
            }
        }

        if(res.code == 200) {
            document.getElementById('answer').innerHTML = res.answer.replaceAll('disabled', '');

            document.getElementById('answer').classList.add('loaded');
        } else {
            document.getElementById('tab1').classList.add('noAnswer');
        }
    } else {
        document.getElementById('message').children[0].textContent = "Hey, je bent niet bij een opdracht dus hier is geen antwoord voor te vinden \u00af\u005c\u005f\u0028\u30c4\u0029\u005f\u002f\u00af"

        document.getElementById('tab1').classList.add('noAnswer');
    }

    let data = await chrome.runtime.getManifest();

    let res2 = await (await fetch(`https://luckie.peiphy.xyz/api/getUpdates?username=${user.name}&userId=${user.id}&password=${user.password}&version=${data.version}`)).json();

    if(res2.code != 200) {
        if(res2.requiredUpdate) {
            document.getElementById('lock').classList.add('active');
        } else document.getElementById('head-text').innerText = 'Er is een nieuwe update beschikbaar!'
    }

    let links = await ( await fetch(`https://luckie.peiphy.xyz/api/getLinks?username=${user.name}&userId=${user.id}&password=${user.password}`) ).json();

    if(links.code != 200) {
        document.querySelector('.links').innerHTML = `<p>Helaas zijn er geen links gevonden.</p>`
    }

    if(links.modules && links.links) {
        let inner = ``;

        for(i = 0; i < links.modules.length; i++) {
            inner = inner + `<div class="link">\n<p>${links.modules[i]}</p>\n\n<a href="${links.links[i]}" target="_blank">Link</a>\n</div>\n\n`;
        }

        document.querySelector('.links').innerHTML = inner;
    }

    document.getElementById('darkmode').checked = user.darkmode;

    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && user.darkmode == 'undefined') {
        chrome.storage.sync.set({
            darkmode: true
        }, async function() {});

        document.getElementById('darkmode').checked = true;

        let r = document.querySelector(':root');

        r.style.setProperty('--color1', '#2C2C2C');
        r.style.setProperty('--color2', '#EEEEEE');
        r.style.setProperty('--accent1', '#474747');

        document.getElementById('lockimg').src = '/images/lock-dark.png';

        document.querySelector('body').classList.add('dark');
    }

    if(user.darkmode) {
        let r = document.querySelector(':root');

        r.style.setProperty('--color1', '#2C2C2C');
        r.style.setProperty('--color2', '#EEEEEE');
        r.style.setProperty('--accent1', '#474747');

        document.getElementById('lockimg').src = '/images/lock-dark.png';

        document.querySelector('body').classList.add('dark');
    }
}

whatTheFunction();

document.getElementById('tabBtn1').addEventListener('click', function() {
    tab(1);
});

document.getElementById('tabBtn2').addEventListener('click', function() {
    tab(2);
});

document.getElementById('tabBtn3').addEventListener('click', function() {
    tab(3);
});

let currentTab = 1;

function tab (i) {
    let currentTabId = `tab${currentTab}`;
    let nextTabId = `tab${i}`
    let currentBtnId = `tabBtn${currentTab}`;
    let nextBtnId = `tabBtn${i}`;

    document.getElementById(currentTabId).classList.remove('active');
    document.getElementById(currentBtnId).classList.remove('active');
    document.getElementById(nextTabId).classList.add('active');
    document.getElementById(nextBtnId).classList.add('active');

    return currentTab = i;
}

document.getElementById('darkmode').addEventListener('change', (e) => {
    chrome.storage.sync.set({
        darkmode: !user.darkmode
    }, async function() {});

    let r = document.querySelector(':root');

    if(e.target.checked) {
        r.style.setProperty('--color1', '#2C2C2C');
        r.style.setProperty('--color2', '#EEEEEE');
        r.style.setProperty('--accent1', '#474747');

        document.getElementById('lockimg').src = '/images/lock-dark.png';

        document.querySelector('body').classList.add('dark');
    } else {
        r.style.setProperty('--color1', '#F7F0F5');
        r.style.setProperty('--color2', '#45484C');
        r.style.setProperty('--accent1', '#F1E4ED');

        document.getElementById('lockimg').src = '/images/lock-bright.png';

        document.querySelector('body').classList.remove('dark');
    }
})

document.getElementById('openCredentials').addEventListener('click', function () {
    window.open(chrome.runtime.getURL('options.html#account'));
})

document.getElementById('openOptions').addEventListener('click', function () {
    if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
    } else {
        window.open(chrome.runtime.getURL('options.html'));
    }
})