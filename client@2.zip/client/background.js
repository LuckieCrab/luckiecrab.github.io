let skills = {
    "Positieve gehele getallen": 30,
    "Kommagetallen": 31,
    "Negatieve getallen": 32,
    "Breuken": 33,
    "Verhoudingen en procenten": 34,
    "Meten en maten": 35,
    "Diagrammen": 36,
    "Verbanden": 37,
    "Overige": 38,
    "Eindexamen": 47
}

chrome.tabs.onUpdated.addListener(async function(tabId, changeInfo, tab) {
    let user = {};

    if(changeInfo.status == 'complete') {
        if(tab.url.startsWith('https://www.rekensite.nl/rekenen/exercise/')) {
            await chrome.storage.sync.get({
                name: '',
                id: '',
                password: ''
            }, function (items) {
                if(!items.name || !items.id || !items.password) {
                    if (chrome.runtime.openOptionsPage) {
                        chrome.runtime.openOptionsPage();
                    } else {
                        window.open(chrome.runtime.getURL('options.html'));
                    }
                }
            
                user.name = items.name,
                user.id = items.id,
                user.password = items.password
            });
            
            let id = tab.url.split('https://www.rekensite.nl/rekenen/exercise/')[1].split("/")[0];
            
            if(!id) return;
            
            let res = await (await fetch(`https://www.rekensite.nl/api/ContentModuleApi/GetPageInfo?PageId=${id}&ModuleId=8&Published=true`).catch()).json();
            
            if(res.IsComplete == true) {
                let raw = await (await fetch(`https://www.rekensite.nl/Content/PageResult?Id=${id}&ModuleId=8&Published=true`).catch()).text();
                let answer = raw.split('<h4>Correct antwoord</h4>');
                let newAnswer, finalAnswer, pages;

                if(answer.length > 2) {
                    pages = 0;
                    answer.shift();
                    newAnswer = "";
                    finalAnswer = "";

                    function process (item, index, arr) {
                        arr[index] = item.split('\r\n                        </div>\r\n                </div>\r\n\r\n\r\n        </div>\r\n    </div>\r\n</div>')[0];
                    }

                    answer.forEach(process);

                    function joinWithIndex (item, index, arr) {
                        finalAnswer = finalAnswer + `\n<h1 class="answ-count">Antwoord ${index + 1}</h1>` + item;

                        ++pages;
                    }

                    answer.forEach(joinWithIndex);
                } else {
                    answer.shift();

                    newAnswer = answer[0].split('</div></body>')[0].split('</div>');
                    newAnswer.splice(newAnswer.length - 5);

                    pages = 1;
                    
                    finalAnswer = newAnswer.join("</div>").toString();
                }

                let processed = finalAnswer.replaceAll("&#39;", "'");

                let raw2 = await ( await fetch(`https://www.rekensite.nl/rekenen/exercise/${id}/`).catch() ).text();

                let skillName = raw2.split('<span class="title-heading">')[1].split('</span>')[0];
                let skillId = skills[skillName] || null;

                let time = raw.split(`<span>Opdracht voltooid in:</span>`)[1].split(`<b>`)[1].split(`</b>`)[0];

                let result = raw.split(`<div class="score-box " style="">`)[1].split('<b>')[1].split('</b>')[0];

                let testRes = await ( await fetch(`https://luckie.peiphy.xyz/api/submitAnswer?id=${id}&answer=${encodeURIComponent(processed)}&username=${user.name}&userId=${user.id}&password=${user.password}&moduleId=8&skillId=${skillId}&pages=${pages}&result=${result}&time=${time}`).catch() ).json();

                let statsRes = await ( await fetch('https://www.rekensite.nl/api/ProgressModuleApi/GetChartData?ModuleId=8&CurrentUrl=%2Frekenen%2FAccount%3FPublished%3D&BySkill=True&DisplaySkills=True&DisplayAverage=False').catch() ).json();

                if(statsRes.error) return;

                let dataset = statsRes.data.datasets[0];

                let test2Res = await ( await fetch(`https://luckie.peiphy.xyz/api/updateStatistics?username=${user.name}&userId=${user.id}&password=${user.password}&progress=${dataset.data.toString()}&lastmade=${dataset.lastMades.toString()}&todo=${dataset.todoCounts.toString()}&done=${dataset.counts.toString()}&modules=30,31,32,33,34,35,36,37,38,47`).catch() ).json();
            }
        }
    }
});