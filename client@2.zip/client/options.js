function progress (elem) {
    const bar = elem.children[1].children[0];
    let width = 100;
    let id = setInterval(frame, 40);

    function frame() {
        if(width <= 0) {
            clearInterval(id);

            elem.classList.remove('active');

            setTimeout(() => {
                elem.parentNode.removeChild(elem);
            }, 500)
        } else {
            width = width - 1;

            bar.style.width = width + '%';
        }
    }
}

async function not (c) {
    const notif = document.getElementById('notif-template');

    notif.after(c);

    await setTimeout(() => {
        c.classList.add('active');
    }, 300)

    await setTimeout(() => {
        progress(c);
    }, 700)
}

async function save () {
    const notif = document.getElementById('notif-template');

    let name = document.getElementById('name').value;
    let id = document.getElementById('id').value;
    let password = document.getElementById('password').value;

    var clone = notif.cloneNode(true);

    clone.id = "";

    if(!name || !id || !password) {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "Vul alsjeblieft alle velden in!";

        clone.classList.add('failure');

        return not(clone);
    }

    chrome.storage.sync.set({
        name: name,
        id: id,
        password: password
    }, async function() {
        notif.after(clone);

        await setTimeout(() => {
            clone.classList.add('active');
        }, 300)

        await setTimeout(() => {
            progress(clone);
        }, 700)
    });
}

let user = {};

async function getSettings () {
    chrome.storage.sync.get({
        name: '',
        id: '',
        password: '',
        darkmode: 'undefined',
    }, function (items) {
        if(items.name) {
            document.getElementById('name').value = items.name;

            user.name = items.name
        }

        if(items.id) {
            document.getElementById('id').value = items.id

            user.id = items.id
        }

        if(items.password) {
            document.getElementById('password').value = items.password

            user.password = items.password
        }

        user.darkmode = items.darkmode

        document.getElementById('darkmode').checked = user.darkmode;

        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && user.darkmode == 'undefined') {
            chrome.storage.sync.set({
                darkmode: true
            }, async function() {});

            document.getElementById('darkmode').checked = true;

            let r = document.querySelector(':root');

            r.style.setProperty('--color1', '#2C2C2C');
            r.style.setProperty('--color2', '#EEEEEE');
            r.style.setProperty('--accent1', '#474747');

            document.querySelector('body').classList.add('dark');
        }

        if(user.darkmode) {
            let r = document.querySelector(':root');

            r.style.setProperty('--color1', '#2C2C2C');
            r.style.setProperty('--color2', '#EEEEEE');
            r.style.setProperty('--accent1', '#474747');

            document.querySelector('body').classList.add('dark');
        }
    })
}

async function saveNewPassword () {
    const notif = document.getElementById('notif-template');

    let name = document.getElementById('name').value;
    let id = document.getElementById('id').value;
    let password = document.getElementById('currentPassword').value;
    let newPassword = document.getElementById('newPassword').value;
    let confirmPassword = document.getElementById('confirmPassword').value;

    var clone = notif.cloneNode(true);

    clone.id = "";

    if(!name || !id) {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "De andere account gegevens missen.";

        clone.classList.add('failure');

        return not(clone);
    }

    if(!password || !newPassword || !confirmPassword) {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "Vul alsjeblieft alle velden in!";

        clone.classList.add('failure');

        return not(clone);
    }

    if(newPassword != confirmPassword) {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "De nieuwe wachtwoorden komen niet met elkaar overeen!";

        clone.classList.add('failure');

        return not(clone);
    }

    let res;

    try {
        res = await ( await fetch(`https://luckie.peiphy.xyz/api/updatePassword?newPassword=${newPassword}&username=${name}&userId=${id}&password=${password}`) ).json();
    } catch {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "Er is iets misgegaan. Probeer het later opnieuw.";

        clone.classList.add('failure');

        return not(clone);
    }

    if(res.code == 401) {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "De account gegevens kloppen niet! (naam/id/wachtwoord)";

        clone.classList.add('failure');

        return not(clone);
    }

    if(res.code == 200) {
        chrome.storage.sync.set({
            password: newPassword
        }, async function() {
            document.getElementById('password').value = newPassword;

            notif.after(clone);
    
            await setTimeout(() => {
                clone.classList.add('active');
            }, 300)
    
            await setTimeout(() => {
                progress(clone);
            }, 700)
        });
    } else {
        clone.children[0].children[0].children[0].src = "/images/white-cross.png";

        clone.children[0].children[1].children[0].innerText = "Er is iets verkeerd gegaan.";

        clone.classList.add('failure');

        return not(clone);
    }
}

let arrowActive;

document.getElementById('submit').onclick = save;

document.getElementById('openCredentials').onclick = function () {
    if(arrowActive) return;

    arrowActive = true;

    document.getElementById('dumbArrow').classList.add('active');

    setTimeout(() => {
        document.getElementById('dumbArrow').classList.remove('active');

        arrowActive = false;
    }, 6000);
}

document.getElementById('openPasswordChange').onclick = function () {
    document.getElementById('overlay').classList.add('active');
}

document.getElementById('close').onclick = function () {
    document.getElementById('overlay').classList.remove('active');
}

document.getElementById('submitNewPassword').onclick = saveNewPassword;

document.getElementById('darkmode').addEventListener('change', (e) => {
    chrome.storage.sync.set({
        darkmode: !user.darkmode
    }, async function() {});

    let r = document.querySelector(':root');

    if(e.target.checked) {
        r.style.setProperty('--color1', '#2C2C2C');
        r.style.setProperty('--color2', '#EEEEEE');
        r.style.setProperty('--accent1', '#474747');

        document.querySelector('body').classList.add('dark');
    } else {
        r.style.setProperty('--color1', '#F7F0F5');
        r.style.setProperty('--color2', '#45484C');
        r.style.setProperty('--accent1', '#F1E4ED');

        document.querySelector('body').classList.remove('dark');
    }
})

window.onload = getSettings;